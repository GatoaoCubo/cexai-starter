---
kind: config
id: bld_config_research_universe
pillar: P09
llm_function: CONSTRAIN
purpose: Nomenclatura, caminhos, limites para produção de research_universe
quality: null
title: "Config Research Universe"
version: "1.0.0"
author: n03_builder
tags: [research_universe, builder, config]
tldr: "Restrições de produção: nomenclatura (p01_ru_{{slug}}.md), limite 6144B, freshness diferenciada por trilha"
domain: "construção de research_universe"
created: "2026-07-17"
updated: "2026-07-17"
8f: "F1_constrain"
keywords: [config research universe, nomenclatura, caminhos, limites, freshness, research_universe, builder, config, casos de borda]
density_score: 0.88
related:
  - bld_config_competitive_matrix
  - bld_config_knowledge_card
---

## Convenção de Nomenclatura (artefatos research_universe)
Padrão: `p01_ru_{{slug}}.md` (ex.: `p01_ru_loja_exemplo_ltda.md`) para saídas de pesquisa unificada.

## Caminhos
`/artifacts/p01/ru/{{slug}}.md`

## Limites
- max_bytes: 6144 (maior que o teto padrão de 5120B -- 6 trilhas exigem mais espaço que um kind de trilha única)
- max_turns: 4 (intake -> coleta -> síntese -> validação)
- effort_level: alto

## Hooks
```
pre_build: null
post_build: null
on_error: null
on_quality_fail: null
```

## Restrições Específicas do Domínio
| Restrição | Valor |
|-----------|-------|
| Escopo | Relatório de pesquisa multi-fonte, uma semente por artefato |
| Dependências | knowledge_card (contexto de domínio), nenhuma Action externa neste pacote público |
| Função 8F primária | F4_reason (classificar semente -> decidir trilhas aplicáveis) |
| Tamanho máximo do artefato | 6144 bytes |

## Seleção de Trilhas por Tipo de Semente
| `seed_type` | Trilhas tipicamente aplicadas | Observação |
|-------------|-------------------------------|------------|
| `cnpj` / `empresa` | Todas as 6 | Ponto de entrada mais completo -- há entidade jurídica identificável |
| `marca` | Todas as 6 (firmografia condicional) | Firmografia só aplica se a marca resolve para uma pessoa jurídica conhecida |
| `produto` | Sinal social, reputação (se há marca), sentimento, SEO, perguntas | Firmografia tipicamente `skipped` |
| `palavra_chave` | SEO (trilha primária), perguntas, demais condicionais | Firmografia e reputação tipicamente `skipped` sem entidade nomeada |
| `store_id` | Sinal social (trilha primária), demais condicionais | Firmografia aplica se o publicador do app/loja resolve para um CNPJ |

Padrão: sempre TENTAR as 6 -- a tabela acima é heurística de expectativa, não uma regra que pula a trilha sem registrar o motivo (ver P06, "Semente x Trilhas Aplicáveis").

## Freshness (janela de validade por trilha)
| Trilha | Janela antes de sinalizar como desatualizada |
|--------|-------------------------------------------------|
| Firmografia | ~12 meses (situação cadastral muda devagar) |
| Sinal Social | ~30 dias (volume de reviews/menções muda rápido) |
| Reputação | ~90 dias (índice Reclame Aqui é revisado com frequência) |
| Sentimento em PT | Mesma janela da trilha-fonte (Sinal Social ou Reputação) |
| SEO | ~60 dias (tendência de busca muda por sazonalidade) |
| Perguntas Multi-Perspectiva | Não expira -- é síntese, revisar só se as trilhas-fonte mudarem materialmente |

## Casos de Borda
| Cenário | Tratamento |
|----------|---------|
| Campo obrigatório do frontmatter ausente | Falha no gate H01; retorna para F6 |
| Semente ambígua (ex.: nome de marca comum a várias empresas) | Pede confirmação ao usuário antes de rodar as trilhas; nunca escolhe silenciosamente |
| `lanes` com menos ou mais de 6 entradas | Falha no gate H04; corrige a lista antes de publicar |
| Todas as 6 trilhas `blocked`/`skipped` | Publica mesmo assim, com `coverage_score: 0.00` e a síntese executiva deixando isso explícito -- nunca aborta silenciosamente |
| Corpo excede 6144 bytes | Corta prosa de síntese; preserva as tabelas das 6 trilhas e a Tabela de Status |

## Propriedades
| Propriedade | Valor |
|----------|-------|
| Kind | `research_universe` |
| Pillar | P01 |
| Domínio | pesquisa multi-fonte a partir de uma semente |
| Pipeline | 8F (F1-F8) |
| Scorer | cex_score.py |
| Compilador | cex_compile.py |
| Retriever | cex_retriever.py |
| Meta de qualidade | 9.0+ |
| Meta de densidade | 0.85+ |

## Artefatos Relacionados
| Artefato | Relacionamento | Pontuação |
|----------|-------------|-------|
| [[bld_config_competitive_matrix]] | sibling | 0.46 |
| [[bld_config_knowledge_card]] | sibling | 0.36 |
| [[bld_schema_research_universe]] | sibling | 0.33 |
| [[bld_architecture_research_universe]] | sibling | 0.30 |
