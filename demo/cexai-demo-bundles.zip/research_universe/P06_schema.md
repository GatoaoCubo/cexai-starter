---
kind: schema
id: bld_schema_research_universe
pillar: P06
llm_function: CONSTRAIN
purpose: Schema formal -- FONTE ÚNICA DA VERDADE para research_universe
quality: null
title: "Schema Research Universe"
version: "1.0.0"
author: n03_builder
tags: [research_universe, builder, schema]
tldr: "Schema formal -- semente + 6 trilhas com status honesto ok/blocked/skipped + procedência para research_universe."
domain: "construção de research_universe"
created: "2026-07-17"
updated: "2026-07-17"
8f: "F1_constrain"
keywords: [research_universe construction, schema research universe, semente, trilhas, status honesto, procedência, research_universe, builder, schema, frontmatter fields]
density_score: 0.88
related:
  - bld_schema_competitive_matrix
  - bld_schema_knowledge_card
---

## Campos do Frontmatter
### Obrigatórios
| Campo | Tipo | Obrigatório | Padrão | Notas |
|-------|------|----------|---------|-------|
| id | string | sim | | Deve corresponder ao Padrão de ID |
| kind | string | sim | | Sempre "research_universe" |
| pillar | string | sim | | P01 |
| title | string | sim | | "Universo de Pesquisa: {Semente}" |
| version | string | sim | | Versão do artefato (ex.: "1.0.0") |
| created | string | sim | | ISO 8601 AAAA-MM-DD |
| updated | string | sim | | ISO 8601 AAAA-MM-DD |
| author | string | sim | | Usuário do analista |
| domain | string | sim | | Domínio/setor da semente |
| quality | null | sim | null | Nunca se autoavalia; peer review atribui |
| tags | list | sim | | Setor/tema da semente, research_universe |
| tldr | string | sim | | "{semente} ({seed_type}) -- N/6 trilhas ok" |
| seed | string | sim | | O valor literal da semente recebida |
| seed_type | string | sim | | Um de: `produto`, `marca`, `cnpj`, `empresa`, `palavra_chave`, `store_id` |
| analysis_date | string | sim | | ISO 8601 AAAA-MM-DD da coleta |
| coverage_score | float | sim | | Fração (0.00-1.00) de trilhas com status `ok` |
| key_findings | string | sim | | Principal achado em uma frase |
| lanes | list[object] | sim | | Exatamente 6 objetos `{lane, status}` -- ver "As 6 Trilhas Canônicas" |

### Recomendados
| Campo | Tipo | Notas |
|-------|------|-------|
| primary_source | string | Fonte que mais contribuiu para o relatório |
| data_sources | list | Nomes das fontes com datas de acesso |
| reviewers | list | Usuários dos revisores pares |

## As 6 Trilhas Canônicas (`lanes[].lane`)
| Slug (frontmatter) | Rótulo em PT-BR | O que cobre |
|---------------------|-----------------|--------------|
| `firmographics` | Firmografia (CNPJ/IBGE) | Razão social, CNAE, porte, situação cadastral |
| `social_signal` | Sinal Social (App Store / Reddit / YouTube) | Avaliações, menções, tom geral em plataformas públicas |
| `reputation` | Reputação (Reclame Aqui) | Índice de reputação, % respondidas/resolvidas |
| `pt_sentiment` | Sentimento em PT | Positivo/neutro/negativo sobre texto já coletado |
| `seo_keywords` | Palavras-chave de SEO | Termos + intenção de busca relacionados a semente |
| `multi_perspective_questions` | Perguntas Multi-Perspectiva | Perguntas por papel (cliente/concorrente/investidor-regulador/parceiro) |

`lanes` deve conter exatamente estas 6 entradas, nesta ordem, sempre -- mesmo quando o status é `blocked` ou `skipped`. O campo `status` de cada uma usa o enum técnico em inglês (`ok` / `blocked` / `skipped`), já estabelecido na descrição original desta capacidade -- preservado aqui como valor de contrato, não traduzido:
- **`ok`** -- dado real foi coletado e citado com fonte + data de acesso.
- **`blocked`** -- a fonte existe, mas não foi acessível neste ambiente/sessão (paywall, anti-bot, login exigido, Action indisponível).
- **`skipped`** -- a trilha não se aplica a este tipo de semente (ex.: firmografia para uma semente `palavra_chave` sem empresa associada).

## Semente x Trilhas Aplicáveis
| `seed_type` | Firmografia | Sinal Social | Reputação | Sentimento PT | SEO | Perguntas Multi-Perspectiva |
|-------------|:---:|:---:|:---:|:---:|:---:|:---:|
| `cnpj` | aplica | aplica | aplica | aplica | opcional | aplica |
| `empresa` | aplica | aplica | aplica | aplica | opcional | aplica |
| `marca` | aplica se resolve p/ pessoa jurídica | aplica | aplica | aplica | aplica | aplica |
| `produto` | tipicamente `skipped` | aplica | aplica se há marca associada | aplica | aplica | aplica |
| `palavra_chave` | `skipped` | aplica se há entidade nomeada | tipicamente `skipped` | aplica se há entidade nomeada | aplica (trilha primária) | aplica |
| `store_id` | aplica se resolve p/ CNPJ do publicador | aplica (trilha primária) | aplica se há empresa identificável | aplica | opcional | aplica |

"Aplica" significa que a trilha DEVE ser tentada; o resultado ainda pode ser `blocked`. Uma trilha marcada como tipicamente `skipped` para um `seed_type` pode virar `ok` se o usuário fornecer dado adicional (ex.: uma `palavra_chave` que o usuário liga explicitamente a uma empresa).

## Padrão de ID
`^p01_ru_[a-z][a-z0-9_]+\.md$`

## Estrutura do Corpo
1. **Sumário Executivo** -- semente, seed_type, data, trilhas ok, achado principal
2. **Firmografia** -- razão social, CNAE, porte, situação cadastral, município/UF
3. **Sinal Social** -- loja de app, Reddit, YouTube
4. **Reputação** -- índice Reclame Aqui, % respondidas/resolvidas
5. **Sentimento em PT** -- distribuição positivo/neutro/negativo com trecho-fonte
6. **Palavras-chave de SEO** -- termos, intenção, volume/tendência
7. **Perguntas Multi-Perspectiva** -- >= 3 papéis distintos
8. **Tabela de Status por Trilha** -- as 6, com motivo quando `blocked`/`skipped`
9. **Procedência Consolidada** -- fontes, método de coleta, confiança geral
10. **Limitações e Próximos Passos**

## Restrições
- O ID deve corresponder exatamente a `^p01_ru_[a-z][a-z0-9_]+\.md$`.
- `analysis_date` deve estar em ISO 8601.
- `lanes` deve ter exatamente 6 entradas, uma por trilha canônica, sempre nesta ordem.
- Todo `status: ok` exige >= 1 fonte com data de acesso no corpo do relatório.
- `coverage_score` deve bater com a contagem real de trilhas `ok` dividida por 6.
- Nenhum valor de firmografia, reputação ou volume de SEO sem fonte citada -- se não há fonte, a trilha é `blocked`, não `ok`.
- Sentimento em PT nunca aparece sem um trecho-fonte apontando para a trilha de origem (Sinal Social ou Reputação).
- O tamanho do arquivo não deve exceder 6144 bytes (maior que o teto padrão de 5120B de um kind de trilha única, dado que este kind cobre 6 trilhas).
- O campo `quality` deve ser `null` (somente peer review).

## Artefatos Relacionados
| Artefato | Relacionamento | Pontuação |
|----------|-------------|-------|
| [[bld_schema_competitive_matrix]] | sibling | 0.42 |
| [[bld_schema_knowledge_card]] | sibling | 0.34 |
| [[bld_output_template_research_universe]] | downstream | 0.33 |
| [[bld_config_research_universe]] | sibling | 0.30 |
